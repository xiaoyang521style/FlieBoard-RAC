# FlieBoard
## 使用方法
pod 'FlieBoard'


##效果图

![FlieBoard-images](https://github.com/xiaoyang521style/FlieBoard/blob/master/Resoures/FlieBoard.gif?raw=true)
