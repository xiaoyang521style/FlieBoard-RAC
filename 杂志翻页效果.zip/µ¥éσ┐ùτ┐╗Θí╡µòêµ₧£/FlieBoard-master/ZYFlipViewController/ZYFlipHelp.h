//
//  ZYFlipHelp.h
//  FlieBoard- Example
//
//  Created by develop5 on 2018/3/8.
//  Copyright © 2018年 yiqihi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface ZYFlipHelp : NSObject
/**当前控制器*/
@property(nonatomic, strong) UIViewController *currentVC;

/**下一个控制器*/
@property(nonatomic, strong) UIViewController *nextVC;


/**容器*/
@property(nonatomic, strong) UIView *containerView;
/**当控制器view*/
@property(nonatomic, strong) UIView *currentView;
/**下一个控制器view*/
@property(nonatomic, strong) UIView *nextView;
/**当控制器上半view*/
@property(nonatomic, strong) UIView *currentUpperView;

/**当控制器下半view*/
@property(nonatomic, strong) UIView *currentBottomView;
/**下一个控制器上半view*/
@property(nonatomic, strong)  UIView *nextUpperView ;

/**下一个控制器下半view*/
@property(nonatomic, strong) UIView *nextBottomView;

/**当控制器上半view阴影*/

@property(nonatomic, strong)UIView *currentUpperShadow;
/**当控制器下半view阴影*/
@property(nonatomic, strong)UIView *currentBottomShadow;
/**下一个控制器上半view*阴影*/
@property(nonatomic, strong)UIView *nextUpperShadow;
/**下一个控制器下半view*阴影*/
@property(nonatomic, strong)UIView *nextBottomShadow;
@property(nonatomic, strong)UIView *view;
+(instancetype)get;
-(void)playSound;
-(void)reset;
-(void)remove;
-(void)setNextOfView;
-(void)setLastOrFirstViewUI;
-(void)setCommonViewUI;
-(void)setDirectionForwardUI;
-(void)setDirectionBackward;
-(void)updateForwardInteractiveTransition:(float)percent;
-(void)updateBackwardInteractiveTransition:(float)percent;
@end
