//
//  ZYFlipAnimation.m
//  FlieBoard- Example
//
//  Created by develop5 on 2018/3/8.
//  Copyright © 2018年 yiqihi. All rights reserved.
//

#define W [UIScreen mainScreen].bounds.size.width
#define H [UIScreen mainScreen].bounds.size.height/2
#define MinShadow  0.0f
#define MaxShadow  0.5f

#import "ZYFlipAnimation.h"

@implementation ZYFlipAnimation

+(void)doCancelAnimWithOrginY:(CGFloat )orginY nextView:(UIView *)nextView currentShadow:(UIView *)currentShadow currentView:(UIView *)currentView currentOtherShadow:(UIView *)currentOtherShadow nextShadow:(UIView *)nextShadow nextOtherShadow:(UIView *)nextOtherShadow FlipAnimationEndCallBack:(FlipAnimationEndCallBack) animationEndCallBack {
    [UIView animateKeyframesWithDuration:0.3 delay:0 options:0 animations:^{
        [UIView addKeyframeWithRelativeStartTime:0.0
                                relativeDuration:0.5
                                      animations:
         ^{
             nextView.frame = CGRectMake(0, orginY, W,  0);
             currentShadow.frame =  currentView.frame;
             currentShadow.alpha = MinShadow;
             currentOtherShadow.alpha = MinShadow;
             nextShadow.alpha = MinShadow;
             nextOtherShadow.alpha = MaxShadow;
         }];
        [UIView addKeyframeWithRelativeStartTime:0.5
                                relativeDuration:0.5
                                      animations:
         ^{
             currentView.frame = CGRectMake(0, orginY ,W ,H);
             nextShadow.frame = nextView.frame;
             currentOtherShadow.alpha = MinShadow;
             currentShadow.alpha = MinShadow;
             nextShadow.alpha = MinShadow;
             nextOtherShadow.alpha = MaxShadow;
             
         }];
    } completion:^(BOOL finished) {
        if (animationEndCallBack) {
            animationEndCallBack();
        }
    }];
}


+(void)doFinishAnimWithOrginY:(CGFloat )orginY currentView:(UIView *)currentView currentShadow:(UIView *)currentShadow nextShadow:(UIView *)nextShadow nextView:(UIView *)nextView nextOtherShadow:(UIView *)nextOtherShadow currentOtherShadow:(UIView *)currentOtherShadow FlipAnimationEndCallBack:(FlipAnimationEndCallBack) animationEndCallBack {
    [UIView animateKeyframesWithDuration:0.3 delay:0 options:0 animations:^{
        [UIView addKeyframeWithRelativeStartTime:0.0  relativeDuration:0.5 animations: ^{
            currentView.frame = CGRectMake(0, H , W, 0);
            currentShadow.frame = currentView.frame;
            currentShadow.alpha = MaxShadow;
            nextShadow.alpha = MinShadow;
        }];
        [UIView addKeyframeWithRelativeStartTime:0.5  relativeDuration:0.5 animations: ^{
            nextView.frame = CGRectMake(0, orginY, W, H);
            nextOtherShadow.frame = nextView.frame;
            nextOtherShadow.alpha = MinShadow;
            currentOtherShadow.alpha = MaxShadow;
        }];
    }completion:^(BOOL finished) {
        if (animationEndCallBack) {
            animationEndCallBack();
        }
    }];
}

@end
