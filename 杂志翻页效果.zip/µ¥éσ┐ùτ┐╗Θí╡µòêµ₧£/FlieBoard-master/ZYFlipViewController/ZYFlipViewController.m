//
//  ZYFlipViewController.m
//  翻页
//
//  Created by ios1 on 2017/10/10.
//  Copyright © 2017年 ios1. All rights reserved.
//



#import "ZYFlipViewController.h"
#import "ZYFlipHeardView.h"
#include <math.h>
#import <ReactiveObjC.h>
#import "ZYFlipAnimation.h"
#import "ZYFlipHelp.h"
#define W [UIScreen mainScreen].bounds.size.width
#define H [UIScreen mainScreen].bounds.size.height/2
#define MinShadow  0.0f
#define MaxShadow  0.5f
typedef NS_ENUM(NSInteger, ZYViewAnimationDirection) {
   ZYViewAnimationDirectionBackward = -1,
   ZYViewAnimationDirectionNone = 0,
   ZYViewAnimationDirectionForward = 1
};

@interface ZYFlipViewController ()
{
    CGPoint oldLocation;
    BOOL _isUp;
    BOOL _isAnimation;
    BOOL _isEnd;
    BOOL _isChange;
    BOOL _isPlayed;
    BOOL _isCancel;
    BOOL _isDownwards;
    CGPoint _translation;
    CGPoint _velocity;
    UIView *_currentView;
    UIView *_currentShadow;
    UIView *_nextView;
    UIView *_nextShadow;
    UIView *_currentOtherShadow;
    UIView *_nextOtherShadow;
}

@property(nonatomic, assign) CGFloat percent;
/**翻页方向*/
@property(nonatomic, assign) ZYViewAnimationDirection direction;
/**当前控制器下标*/
@property(nonatomic, assign) NSInteger currentIndex;
@property(nonatomic, strong) ZYFlipHelp *flipHelp;
/**头部*/
@property(nonatomic,strong)ZYFlipHeardView *flipHeardView;

@end

@implementation ZYFlipViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    //添加手势
    [self.view addGestureRecognizer:self.pan];
    [self.view addSubview:self.flipHeardView];
    [self addPlaySoundRAC];
    // Do any additional setup after loading the view.
}

#pragma mark 懒加载
/**手势*/
-(UIPanGestureRecognizer *)pan {
    if (_pan == nil) {
        _pan = [[UIPanGestureRecognizer alloc]init];
        //[_pan addTarget:self action:@selector(panFlipWithGesture:)];
      
        _pan.minimumNumberOfTouches = 1;
        _pan.maximumNumberOfTouches = 2;
        [self addPanRAC];
    }
    return _pan;
}

//添加震动ARC
-(void)addPlaySoundRAC {
    [RACObserve(self, percent) subscribeNext:^(id  _Nullable x) {
        if (self.direction == ZYViewAnimationDirectionForward) {
            if (self.currentIndex == self.viewControllers.count- 1 ) {
                if (self.percent > 0.2) {
                    self.percent = 0.2;
                    if (!_isPlayed) {
                        [self.flipHelp playSound];
                    }
                    _isPlayed = YES;
                }else{
                    _isPlayed = NO;
                }
            }
            [self.flipHelp updateForwardInteractiveTransition:self.percent];
        }
        if (self.direction == ZYViewAnimationDirectionBackward) {
            if (self.currentIndex == 0 ) {
                if (self.percent > 0.2) {
                    self.percent = 0.2;
                    if (!_isPlayed) {
                        [self.flipHelp playSound];
                    }
                    _isPlayed = YES;
                }else{
                    _isPlayed = NO;
                }
            }
            [self.flipHelp updateBackwardInteractiveTransition:self.percent];
        }
    }];
}

//添加手势RAC
-(void)addPanRAC {
    [self.pan.rac_gestureSignal subscribeNext:^(__kindof UIGestureRecognizer * _Nullable x) {
        /**手势状态*/
        UIGestureRecognizerState state = [(UIGestureRecognizer *)x state];
        UIPanGestureRecognizer *gestureRecognizer = x;
        _translation = [gestureRecognizer translationInView:self.view];
        switch (state) {
            case UIGestureRecognizerStateBegan: {
                /**设置翻页开始状态*/
                 if (ABS(_translation.y) - ABS(_translation.x)>= 0) {
                    _velocity = [gestureRecognizer velocityInView:self.view];
                    _isDownwards = (_velocity.y > 0);
                    CGPoint nowPoint = [gestureRecognizer locationInView:self.view];
                    oldLocation  = nowPoint;
                    RACSignal *beganRequest = [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
                         // 发送手势开始请求
                         if (!_isAnimation){
                             [subscriber sendNext:@(_isDownwards)];
                         }
                         return nil;
                     }];
                     RACSignal *animationRequest = [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
                         // 发送动画请求
                         [subscriber sendNext:@(_isAnimation)];
                         return nil;
                     }];
                    [self rac_liftSelector:@selector(willUpdateUIWithBeganRequest:animationRequest:) withSignalsFromArray:@[beganRequest,animationRequest]];
                     _isAnimation = YES;
                     _isEnd = NO;
                 }
            }
                break;
            case  UIGestureRecognizerStateChanged: {
                CGRect viewRect = self.view.bounds;
                CGPoint translation = [gestureRecognizer translationInView:self.view];
                CGFloat percent = (double)translation.y / (double)viewRect.size.height;
                RACSignal *changeRequest = [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
                    // 发送手势变化请求
                    if (!_isChange && !ABS(translation.y) - ABS(translation.x)<= 0){
                        [subscriber sendNext:@(percent)];
                    }
                    return nil;
                }];
                RACSignal *locationRequest = [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
                    // 发送位置变化请求
                     CGPoint location = [gestureRecognizer locationInView:self.view];
                    [subscriber sendNext:@(location)];
                    return nil;
                }];
                [self rac_liftSelector:@selector(updateUIWithChangeRequest:locationRequest:) withSignalsFromArray:@[changeRequest,locationRequest]];
            }
                break;
            case  UIGestureRecognizerStateEnded:
            case  UIGestureRecognizerStateCancelled:
            case  UIGestureRecognizerStateFailed:
            case  UIGestureRecognizerStatePossible: {
                [self endUpdateUI];
            }
                break;
            default:
                break;
        }
    }];
}

//手势页面更新开始
- (void)willUpdateUIWithBeganRequest:(id)data animationRequest:(id)data1 {
    if (_isDownwards) {
       [self.delegate flipWillDoAction];
       self.direction = ZYViewAnimationDirectionBackward;
       [self setNextOfViewOfIndex:self.currentIndex - 1];
    } else {
       [self.delegate flipWillDoAction];
       self.direction = ZYViewAnimationDirectionForward;
       [self setNextOfViewOfIndex:self.currentIndex +1];
    }
}

//手势页面正在更新
- (void)updateUIWithChangeRequest:(id)data locationRequest:(id)data1 {
    CGFloat percent = [data floatValue];
    CGPoint location = [data1 CGPointValue];
    if (self.direction == ZYViewAnimationDirectionForward && percent > 0) {
        self.percent = 0;
    }else if(self.direction == ZYViewAnimationDirectionBackward && percent < 0) {
        self.percent = 0;
    }else{
        percent = fabs(percent);
        percent = MIN(1.0, MAX(0.0, percent));
        self.percent = percent;
        double absY = fabs(location.y);
        double oldAbsY = fabs(oldLocation.y);
        if (absY -oldAbsY < 0) {
            _isUp = YES;
        }
        if (absY - oldAbsY > 0){
            _isUp = NO;
        }
        oldLocation  = location;
    }
}

//手势页面更新结束
-(void)endUpdateUI {
    if (_isEnd || !_isAnimation) {
        return;
    }
    if (!_isChange) {
        [self.delegate flipDidAction];
    }
    _isEnd = YES;
    _isChange =YES;
    if (self.direction == ZYViewAnimationDirectionForward){
        if ( self.currentIndex == self.viewControllers.count - 1) {
            _isCancel = YES;
            [self cancelInteractiveTransition];
        }else{
            if (_isUp) {
                _isCancel = NO;
                [self finishInteractiveTransition];
            }else{
                _isCancel = YES;
                [self cancelInteractiveTransition];
            }
        }
    }else{
        if (self.currentIndex == 0) {
            _isCancel = YES;
            [self cancelInteractiveTransition];
        }else{
            if (!_isUp) {
                _isCancel = NO;
                [self finishInteractiveTransition];
            }else{
                _isCancel = YES;
                [self cancelInteractiveTransition];
            }
        }
    }
}

#pragma getter && setter方法
-(ZYFlipHelp *)flipHelp {
    if (_flipHelp == nil) {
        _flipHelp = [ZYFlipHelp get];
        _flipHelp.view = self.view;
    }
    return _flipHelp;
}

/**控制器集合*/
-(void)setViewControllers:(NSMutableArray *)viewControllers {
    _viewControllers = viewControllers;
    if (self.flipHelp.currentVC) {
        [self.flipHelp reset];
    }
    for ( UIViewController *viewContoller  in viewControllers) {
        [self addChildViewController:viewContoller];
    }
    self.flipHelp.currentVC = _viewControllers[0];
    [self.view addSubview:self.flipHelp.currentVC.view];
    self.currentIndex = 0;
}

-(ZYFlipHeardView *)flipHeardView {
    if (_flipHeardView == nil) {
        _flipHeardView = [[ZYFlipHeardView alloc]init];
    }
    return _flipHeardView;
}

-(void)setHeardString:(NSString *)heardString {
    _heardString = heardString;
    self.flipHeardView.textLabel.text =_heardString;
}

#pragma mark 设置控制器view 和 截图
-(void)setNextOfViewOfIndex:(NSInteger) index {
    if (_isAnimation) {
        return;
    }
    [self.flipHelp setNextOfView];
    if (index < 0 || index > self.viewControllers.count - 1) {
         //是最后一页和第一页
        [self.flipHelp setLastOrFirstViewUI];
    }else{
          self.flipHelp.nextVC = self.viewControllers[index];
        //不是最后一页和第一页
        [self.flipHelp setCommonViewUI];
        if (self.direction == ZYViewAnimationDirectionForward) {
            [self.flipHelp setDirectionForwardUI];
        }else{
            [self.flipHelp setDirectionBackward];
        }
    }
    [self.flipHelp.currentVC.view removeFromSuperview];
}

#pragma mark  翻页动画
-(void)reset{
    for (UIView *view in self.view.subviews) {
        [view removeFromSuperview];
    }
    [self.flipHelp remove];
    [self.view addSubview:self.flipHeardView];
    [self.view addSubview:self.flipHelp.currentVC.view];
    _isAnimation = NO;
    _isEnd = NO;
    _isChange = NO;
}

-(void)cancelAnimEnd {
    [self reset];
}
-(void)finishAnimEnd {
    self.flipHelp.currentVC = self.flipHelp.nextVC;
    [self reset];
}

-(void)cancelInteractiveTransition{
    CGFloat orginY = 0;
     if (self.direction == ZYViewAnimationDirectionBackward) {
         _currentView = self.flipHelp.currentBottomView;
         _nextView = self.flipHelp.nextUpperView;
         _currentShadow = self.flipHelp.currentBottomShadow;
         _currentOtherShadow = self.flipHelp.currentUpperShadow;
         _nextShadow = self.flipHelp.nextUpperShadow;
         _nextOtherShadow = self.flipHelp.nextBottomShadow;
         orginY = H;
     }
    
     if (self.direction == ZYViewAnimationDirectionBackward) {
         _currentView = self.flipHelp.currentUpperView;
         _nextView =  self.flipHelp.nextBottomView;
         _currentShadow = self.flipHelp.currentUpperShadow;
         _currentOtherShadow = self.flipHelp.currentBottomShadow;
         _nextShadow = self.flipHelp.nextUpperShadow;
         _nextOtherShadow = self.flipHelp.nextBottomShadow;
         orginY = 0;
     }
    
    __weak typeof(self) weakSelf = self;
    if (_isCancel) {
        [ZYFlipAnimation doCancelAnimWithOrginY:orginY nextView:_nextView currentShadow:_currentShadow currentView:_currentView currentOtherShadow:_currentOtherShadow nextShadow:_nextShadow nextOtherShadow:_nextOtherShadow FlipAnimationEndCallBack:^{
            [weakSelf cancelAnimEnd];
        }];
    }
}

-(void)finishInteractiveTransition {
    NSInteger currentIndex = self.currentIndex;
    CGFloat orginY = 0;
    if (self.direction == ZYViewAnimationDirectionForward) {
        _currentView = self.flipHelp.currentBottomView;
        _currentShadow = self.flipHelp.currentBottomShadow;
        _nextShadow = self.flipHelp.nextBottomShadow;
        _nextView = self.flipHelp.nextUpperView;
        _nextOtherShadow = self.flipHelp.nextUpperShadow;
        _currentOtherShadow = self.flipHelp.currentUpperShadow;
        currentIndex ++;
        orginY = 0;
    }

    if (self.direction == ZYViewAnimationDirectionBackward) {
        _currentView = self.flipHelp.currentUpperView;
        _currentShadow = self.flipHelp.currentUpperShadow;
        _nextShadow = self.flipHelp.nextUpperShadow;
        _nextView = self.flipHelp.nextBottomView;
        _nextOtherShadow = self.flipHelp.nextBottomShadow;
        _currentOtherShadow = self.flipHelp.currentUpperShadow;
        currentIndex --;
        orginY = H;
    }

    __weak typeof(self) weakSelf = self;
    [ZYFlipAnimation doFinishAnimWithOrginY:orginY currentView:_currentView currentShadow:_currentShadow nextShadow:_nextShadow nextView:_nextView nextOtherShadow:_nextOtherShadow currentOtherShadow:_currentOtherShadow FlipAnimationEndCallBack:^{
        [weakSelf finishAnimEnd];
        weakSelf.currentIndex = currentIndex;
    }];
}

-(void)dealloc {
    NSLog(@"ZYFlipViewController");
    [self.viewControllers removeAllObjects];
    self.viewControllers = nil;
    [self.flipHelp remove];
}

@end
