//
//  ZYFlipAnimation.h
//  FlieBoard- Example
//
//  Created by develop5 on 2018/3/8.
//  Copyright © 2018年 yiqihi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef void (^FlipAnimationEndCallBack)(void);

@interface ZYFlipAnimation : NSObject
+(void)doCancelAnimWithOrginY:(CGFloat )orginY nextView:(UIView *)nextView currentShadow:(UIView *)currentShadow currentView:(UIView *)currentView currentOtherShadow:(UIView *)currentOtherShadow nextShadow:(UIView *)nextShadow nextOtherShadow:(UIView *)nextOtherShadow FlipAnimationEndCallBack:(FlipAnimationEndCallBack) animationEndCallBack;

+(void)doFinishAnimWithOrginY:(CGFloat )orginY currentView:(UIView *)currentView currentShadow:(UIView *)currentShadow nextShadow:(UIView *)nextShadow nextView:(UIView *)nextView nextOtherShadow:(UIView *)nextOtherShadow currentOtherShadow:(UIView *)currentOtherShadow FlipAnimationEndCallBack:(FlipAnimationEndCallBack) animationEndCallBack;
@end
