//
//  ZYFlipHelp.m
//  FlieBoard- Example
//
//  Created by develop5 on 2018/3/8.
//  Copyright © 2018年 yiqihi. All rights reserved.
//
#define W [UIScreen mainScreen].bounds.size.width
#define H [UIScreen mainScreen].bounds.size.height/2
#define MinShadow  0.0f
#define MaxShadow  0.5f

#import "ZYFlipHelp.h"
#import <AudioToolbox/AudioToolbox.h>

static ZYFlipHelp *flipHelp;
static dispatch_once_t flipHelp_once;
@implementation ZYFlipHelp
+(instancetype)get {
    dispatch_once(&flipHelp_once, ^{
        flipHelp = [[ZYFlipHelp alloc]init];
    });
    
    return flipHelp;
}

-(void)reset {
    [self.currentVC removeFromParentViewController];
    [self.currentVC.view removeFromSuperview];
    self.nextVC = nil;
    self.nextView = nil;
    self.currentVC = nil;
    self.containerView = nil;
    self.currentView = nil;
}

-(void)remove{
    self.currentUpperView = nil;
    self.currentBottomView = nil;
    self.currentUpperShadow = nil;
    self.currentBottomShadow = nil;
    self.nextUpperView = nil;
    self.nextBottomShadow = nil;
    self.nextUpperShadow = nil;
    self.nextBottomView = nil;
}

-(void)setNextOfView {
    UIWindow * window = [UIApplication sharedApplication].keyWindow;
    [window makeKeyAndVisible];
    self.currentView = self.currentVC.view;
    self.containerView = self.view;
    self.currentUpperView = [self createUpperHalf: self.currentView];
    self.currentBottomView = [self createBottomHalf: self.currentView];
    [self.containerView addSubview:self.currentUpperView];
    [self.containerView addSubview:self.currentBottomView];
    self.currentUpperShadow = [[UIView alloc] initWithFrame:self.currentUpperView.frame];
    self.currentUpperShadow.backgroundColor = [UIColor blackColor];
    self.currentBottomShadow = [[UIView alloc] initWithFrame:self.currentBottomView.frame];
    self.currentBottomShadow.backgroundColor = [UIColor blackColor];
}

-(void)setLastOrFirstViewUI {
    self.currentUpperShadow = [[UIView alloc] initWithFrame:self.currentUpperView.frame];
    self.currentUpperShadow.backgroundColor = [UIColor blackColor];
    self.currentBottomShadow = [[UIView alloc] initWithFrame:self.currentBottomView.frame];
    self.currentBottomShadow.backgroundColor = [UIColor blackColor];
    [self.containerView insertSubview:self.currentUpperShadow aboveSubview:self.currentUpperView];
    [self.containerView insertSubview:self.currentBottomShadow aboveSubview:self.currentBottomView];
    self.currentUpperShadow.alpha = MinShadow;
    self.currentBottomShadow.alpha = MinShadow;
    [self.containerView insertSubview:self.currentUpperShadow aboveSubview:self.currentUpperView];
    [self.containerView insertSubview:self.currentBottomShadow aboveSubview:self.currentBottomView];
}

-(void)setCommonViewUI {
    [self.nextVC removeFromParentViewController];
    self.nextView  = self.nextVC.view;
    self.nextUpperView = [self createUpperHalf: self.nextView];
    self.nextBottomView = [self createBottomHalf: self.nextView];
    self.nextUpperShadow  = [[UIView alloc] initWithFrame:self.nextUpperView.frame];
    self.nextUpperShadow.backgroundColor = [UIColor blackColor];
    self.nextBottomShadow = [[UIView alloc] initWithFrame:self.nextBottomView.frame];
    self.nextBottomShadow.backgroundColor = [UIColor blackColor];
}

-(void)setDirectionForwardUI {
    [self.nextUpperView setFrame:CGRectMake(0, H, W, 0)];
    [self.containerView insertSubview:self.nextView belowSubview:self.currentUpperView];
    [self.containerView addSubview:self.nextUpperView];
    self.nextUpperShadow.frame = self.nextUpperView.frame;
    self.currentUpperShadow.alpha = MinShadow;
    self.currentBottomShadow.alpha = MinShadow;
    self.nextUpperShadow.alpha = MinShadow;
    self.nextBottomShadow.alpha = MaxShadow;
    
    [self.containerView insertSubview:self.currentUpperShadow aboveSubview:self.currentUpperView];
   [self.containerView insertSubview:self.currentBottomShadow aboveSubview:self.currentBottomView];
    [self.containerView insertSubview:self.nextUpperShadow aboveSubview:self.nextUpperView];
    [self.containerView insertSubview:self.nextBottomShadow belowSubview:self.currentBottomView];
}

-(void)setDirectionBackward {
    [self.nextBottomView  setFrame:CGRectMake(0, H, W, 0)];
    [self.containerView insertSubview:self.nextView belowSubview:self.currentUpperView];
    [self.containerView addSubview:self.nextBottomView];
    self.nextBottomShadow.frame = self.nextBottomView.frame;
    self.currentUpperShadow.alpha = MinShadow;
    self.nextBottomShadow.alpha = MinShadow;
    self.nextUpperShadow.alpha = MaxShadow;
    self.nextBottomShadow.alpha = MinShadow;
    [self.containerView insertSubview:self.currentUpperShadow aboveSubview:self.currentUpperView];
    [self.containerView insertSubview:self.nextBottomShadow aboveSubview:self.currentBottomView];
    [self.containerView insertSubview:self.nextUpperShadow belowSubview:self.currentUpperView];
    [self.containerView insertSubview: self.nextBottomShadow aboveSubview:self.nextBottomShadow];
}

-(void)updateForwardInteractiveTransition:(float)percent {
    if (percent <= 0.5f) {
        self.currentBottomView.frame = CGRectMake(0, self.currentBottomView.frame.origin.y, W, H * (1-percent/0.5));
        self.nextUpperView.frame = CGRectMake(0,  self.currentBottomView.frame.origin.y,  W, 0);
        self.currentBottomShadow.frame = self.currentBottomView.frame;
        self.currentBottomShadow.alpha = MaxShadow * ( percent/0.5);
        self.nextBottomShadow.alpha = MaxShadow * (1 - percent/0.5);
        self.nextUpperShadow.alpha = MaxShadow;
        self.nextUpperShadow.frame = self.nextUpperView.frame;
        
    } else {
        self.currentBottomShadow.frame = self.currentBottomView.frame;
        self.currentBottomShadow.alpha = MaxShadow ;
        self.nextUpperShadow.alpha = MaxShadow ;
        self.nextBottomShadow.alpha = MinShadow ;
        self.currentBottomView.frame = CGRectMake(0, self.currentBottomView.frame.origin.y, W,0);
        self.nextUpperView.frame = CGRectMake(0,  H -( H*  ((percent - 0.5)/0.5)  ) ,  W,  H * ((percent - 0.5)/0.5) );
        self.nextUpperShadow.frame = self.nextUpperView.frame;
        self.nextUpperShadow.alpha = MaxShadow * (1-(percent - 0.5)/0.5);
        self.currentUpperShadow.alpha = MaxShadow * (percent - 0.5)/0.5;
    }
}

-(void)updateBackwardInteractiveTransition:(float)percent {
    if (percent <= 0.5f) {
        self.currentUpperView.frame = CGRectMake(0, H - H * (1-percent/0.5), W, H * (1 - percent/0.5));
        self.nextBottomView.frame = CGRectMake(0, H, W, 0);
        self.currentUpperShadow.frame = self.currentUpperView.frame;
        self.currentUpperShadow.alpha = MaxShadow * (percent/0.5);
        self.nextBottomShadow.alpha = MaxShadow * (1 - percent/0.5);
        self.nextUpperShadow.alpha = MaxShadow * (1 - percent/0.5);
        self.nextBottomShadow.alpha = MaxShadow;
        self.nextBottomShadow.frame = self.nextBottomView.frame;
    }else if( percent <= 1.0f) {
        self.nextBottomView.frame = CGRectMake(0, H, W, H * ((percent - 0.5)/0.5));
        self.currentUpperView.frame = CGRectMake(0, H, W, 0);
        
        self.currentUpperShadow.frame = self.currentUpperView.frame;
        self.nextBottomShadow.frame = self.nextBottomView.frame;
        self.nextBottomShadow.alpha = MaxShadow * (1-(percent - 0.5)/0.5);;
        self.currentUpperShadow.alpha = MaxShadow * ((percent - 0.5)/0.5);
        self.currentBottomShadow.alpha = MaxShadow * ((percent - 0.5)/0.5);
    }
}

#pragma mark 截屏
- (UIView *)createUpperHalf:(UIView *)view {
    CGRect snapRect = CGRectMake(0, 0, view.frame.size.width, view.frame.size.height / 2);
    UIView *topHalf = [view resizableSnapshotViewFromRect:snapRect afterScreenUpdates:YES withCapInsets:UIEdgeInsetsZero];
    topHalf.userInteractionEnabled = NO;
    return topHalf;
}

- (UIView *)createBottomHalf:(UIView *)view {
    CGRect snapRect = CGRectMake(0, CGRectGetMidY(view.frame), view.frame.size.width, view.frame.size.height / 2);
    UIView *bottomHalf = [view resizableSnapshotViewFromRect:snapRect afterScreenUpdates:YES withCapInsets:UIEdgeInsetsZero];
    CGRect newFrame = CGRectOffset(bottomHalf.frame, 0, bottomHalf.bounds.size.height);
    bottomHalf.frame = newFrame;
    bottomHalf.userInteractionEnabled = NO;
    return bottomHalf;
}

-(void)playSound {
    AudioServicesPlaySystemSound(1519);
}

@end
