//
//  ZYFlipHeardView.h
//  FlieBoard
//
//  Created by ios1 on 2017/10/24.
//  Copyright © 2017年 ios1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZYFlipHeardView : UIView
@property(nonatomic,strong)UILabel *textLabel;

@end
