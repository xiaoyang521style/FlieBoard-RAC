//
//  ZYDetailViewController.h
//  翻页
//
//  Created by ios1 on 2017/10/10.
//  Copyright © 2017年 ios1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZYDetailViewController : UIViewController
@property(nonatomic,strong)UILabel *numLa;
@property(nonatomic,strong)NSString *numStr;
@end
